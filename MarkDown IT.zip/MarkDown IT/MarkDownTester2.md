# Family

**Family** 
My mother is a very important person in my life that has helped me get this far
 I wanted to dedicate a page or two to her.

**Essay to my mother**

  Everybody has that one person in their life that is really important to them. Everyone has a hero 

 in their life. My hero is my mother. She has done a lot for me and pushes me to be greater still.

  My mother has always been there for me. She was there when I was born, she was there when I 

started going to school, and she has helped me get through life. Unfortunately, I was Jumping schools 

frequently and having to make new friends over again. The one thing that made it bearable was my 

mom’s attitude and output. She was so positive and she really cares about me. Without my mom I would 

not be that happy, and I probably wouldn’t be going to Rockhurst or playing soccer. My mom is a real 

hero to me. 

**HouseHold**
I have a step father and a Sister that are very important to me as well. My family has gotten me through a lot of rough times including the covid pandemic. I am very thankful for everything they have done for me and will continue to do for me.
