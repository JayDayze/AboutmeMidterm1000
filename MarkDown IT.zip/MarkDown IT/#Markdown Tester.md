
# Jacob Burrell_Kogo

 My name is Jacob Burrell_Kogo. I am a student at Mizzou, but before that
 I attended school at Rockhurst Highschool. College is a different experience and rather
 difficult. Regardless I try my best everyday on each assignment. 

 **Hobbies**
  -  playing video games in my spare time  
  -  read manga when I can find a decent collection
  - watch movies for fun. Recently I finished watching _The Amazing SpiderMan 2_

**Favorite Foods**
- Chicken Sandwhiches
- Fried Chicken
- Mac and Cheese Casserole
- Oreo Creme Brownies *Homemade
  
<!DOCTYPE html >
<html>
<head>
<h3> Video Games </h3>
<body>
  <img src= "https://www.google.com/imgres?imgurl=https%3A%2F%2Fakm-img-a-in.tosshub.com%2Findiatoday%2Fimages%2Fstory%2F202004%2Fgame-2294201_1280.jpeg%3F6S0Y13YT5h7EPuSp1JMcFjcnCl.BVOmD%26size%3D1200%3A675&imgrefurl=https%3A%2F%2Fwww.indiatoday.in%2Flifestyle%2Fhealth%2Fstory%2Fplaying-video-games-can-give-better-eye-to-hand-coordination-and-improve-memory-study-1666912-2020-04-14&tbnid=ZpsbHfa9qlkgYM&vet=12ahUKEwj8-p_YrNfzAhUG76wKHeKZCBYQMygJegUIARC7AQ..i&docid=tbARw_hRr1vyeM&w=1200&h=675&q=images%20of%20video%20games%20small%20image%20address%20links%20&ved=2ahUKEwj8-p_YrNfzAhUG76wKHeKZCBYQMygJegUIARC7AQ"
 width="100" height="100">
 <p><a href="https://www.pocket-lint.com/games/buyers-guides/xbox/132050-best-xbox-one-games-the-must-have-games-to-own-for-xbox"> Top Xbox Games </a></p>

 </body>
 </html>
