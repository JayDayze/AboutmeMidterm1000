# Web Comics

My Senior year of highschool and my freshman year of college, I have read a lot of webtoon comics
These are just comic books on an app. The stories are amazing and a great way to past time

**Dice** By hyunseok yu
- Action
Dice is an interesting webcomic that focuses on Action and an Interesting Reality. People have dice that can change any attribute about themselves that they want. Speed, Strength, looks. Eventually dice get scarce and everyone ends up fighting for them. Really good stuff

<!DOCTYPE html >
<html>
<head>
<h3> Dice </h3>
<body>
  <img src= "https://www.webtoons.com/en/fantasy/dice/season-4-ep-204/viewer?title_no=64&episode_no=205"
 width="100" height="100">
 <p><a href="https://www.webtoons.com/en/top"> Webtoon </a></p>

 </body>
 </html>


**Unordinary** By Uru Chan
- Superhero
Unordinary is a unique super hero type comic that focuses on school kids each with their own type of superpower. As the main character tries to run from his past
<!DOCTYPE html >
<html>
<head>
<h3> Unordinary </h3>
<body>
  <img src= "https://www.webtoons.com/en/super-hero/unordinary/episode-39/viewer?title_no=679&episode_no=41"
 width="100" height="100">
 <p><a href="https://www.webtoons.com/en/top"> Webtoon </a></p>

 </body>
 </html>

**Boxer**
- Sports
This is a nerve racking comic about an insanely strong boxer with inhuman speed strength and reaction time. Slowly but surely he is led down a dark path and only one man is strong enough to stand a chance against him. Exciting reading!

<!DOCTYPE html >
<html>
<head>
<h3> Boxer </h3>
<body>
  <img src= "https://www.webtoons.com/en/sports/the-boxer/ep-13-the-gift-2/viewer?title_no=2027&episode_no=13"
 width="100" height="100">
 <p><a href="https://www.webtoons.com/en/top"> Webtoon </a></p>

 </body>
 </html>