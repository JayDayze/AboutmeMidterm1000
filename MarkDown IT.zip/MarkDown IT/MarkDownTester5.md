#Exercise

For the past several years I have been into exercising.
 A lot of times I have the urge to just run or get
in some type of physical activity.

**Soccer**
I played soccer in school
I also got the chance to play soccer with my friends in a league
Played soccer at mizzou for fun

**Running**
Ran track in middle school
Ran constant long distance training over the summer of 2021
2-4 miles is my type distance for running