# Occupation

**Notestoself** 
For my entire senior year, I worked at a Sock Company in Kansas City called Notestoself. This company is in the business of selling and donating socks with positve messages. The owner Laura worked really hard to get her business off the ground and I have a huge amount of respect for her. 

<!DOCTYPE html >
<html>
<head>
<h3> Notestoself </h3>
<body>
  <img src="https://www.google.com/imgres?imgurl=https%3A%2F%2Fcouponseeker.com%2Fstorage%2Fnotes-to-self.jpg&imgrefurl=https%3A%2F%2Fcouponseeker.com%2Fnotes-to-self-promo-codes%2F&tbnid=tHqtFjAIjeClhM&vet=12ahUKEwi-v4TQ1tfzAhVLZKwKHaIxAqMQMygLegUIARDtAQ..i&docid=YeA42B0jUIEVmM&w=300&h=300&itg=1&q=notestoself&ved=2ahUKEwi-v4TQ1tfzAhVLZKwKHaIxAqMQMygLegUIARDtAQ"
 width="100" height="100">
 <p><a href="https://www.notestoself.com/"> Notestoself </a></p>

 </body>
 </html>

**Socks** There is a sock out there for just about anyone
- Crew 
- ankle
- infant
- wool
